package com.company;

public class Price implements ApplePrice{
    public void display(){

        System.out.println("Price of Apple " + ApplePrice.applePriceForOneKg);
    }

}
