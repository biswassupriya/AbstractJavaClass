package com.company;

public enum AppleColor {
    RED,
    GREEN,
    PINK
}
