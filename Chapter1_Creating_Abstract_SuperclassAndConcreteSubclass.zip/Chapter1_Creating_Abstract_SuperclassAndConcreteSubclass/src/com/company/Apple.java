package com.company;

import com.company.food.Fruit;

public class Apple extends Fruit {

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        if(colour.equalsIgnoreCase(AppleColor.valueOf(colour.toUpperCase()).toString())) {
            this.colour = colour;
        } else {
            System.out.println("Unable to set colour " + colour);
        }

    }

    private String colour;

    public void getFruitColor() {
        colour="red";
        System.out.println("Apple is " + colour);
    }

    public void getAppleMessage() {
        System.out.println("Apple a Day Keeps Doctors Away");
    }

    public int getApplePerDayCount(int i) {
        return i;

    }

}
