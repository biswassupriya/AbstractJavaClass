package com.company;

public class Main {

    public static void main(String[] args) {
        // write your code here
        Apple obj = new Apple();
        obj.getFruitColor();
        obj.recommendToEat();
        obj.getAppleMessage();
        //obj.NoOfApplePerDay(1);
        System.out.println(obj.getApplePerDayCount(2));
        NestedClass obj1 = new NestedClass();
        NestedClass.InnerNestedClass obj3 = obj1.new InnerNestedClass();
        System.out.println("The Apple has lot of " + obj1.appleHas);
        System.out.println("No of Apple Everyone should have per day :" + obj3.noOfAppleForAdultPerDay);
        System.out.println();
        Price obj4 = new Price();
        obj4.display();
        //System.out.println();
        System.out.println(AppleColor.RED);

        obj.setColour("red");
        obj.getFruitColor();

        //obj.setColour("white");
       // obj.getFruitColor();

    }
}
