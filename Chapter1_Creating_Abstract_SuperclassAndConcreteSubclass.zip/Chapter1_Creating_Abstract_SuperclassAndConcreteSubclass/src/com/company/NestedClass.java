package com.company;

public class NestedClass {
    String appleHas = "Fibre";

    class InnerNestedClass{
        int noOfAppleForAdultPerDay = 1;
    }
}
