package com.company.food;

import com.company.ApplePrice;

public abstract class Fruit {
    public abstract void getFruitColor();
    public void recommendToEat() {
        System.out.println("Evryone Shoould eat fruits to stay fit and healthy");
    }


}
