package com.company;

public interface ApplePrice {
     String applePriceForOneKg = "£10";
    void display();
}
